
export type UserMode = 'normal' | 'hearing' | 'sight' | 'healing';

export interface Message {
  role: 'user' | 'model';
  text: string;
  image?: string;
  generatedVisual?: string;
  timestamp: number;
}

export interface ExplanationResponse {
  subject: string;
  assessment: string;
  explanation: string;
  followUp: string;
  visualPrompt?: string;
  detectedConfusion?: boolean;
  groundingLinks?: Array<{ title: string; uri: string }>;
}

export interface AppSettings {
  userName: string;
  userMode: UserMode;
  isCameraOn: boolean;
  advancedMode: boolean;
}

/**
 * Interface representing the AI Studio API key management tools.
 * Required for compliant usage of Gemini 3 models.
 */
export interface AIStudio {
  hasSelectedApiKey: () => Promise<boolean>;
  openSelectKey: () => Promise<void>;
}

declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
    renderMathInElement: (element: HTMLElement, options: any) => void;
    /**
     * The aistudio property is used to handle mandatory API key selection
     * for premium models like gemini-3-pro-image-preview.
     */
    aistudio: AIStudio;
  }
}
