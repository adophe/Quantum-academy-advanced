
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ExplanationResponse, UserMode } from "../types";

export class AdaptiveAcademyService {
  private getClient() {
    // Uses the automatically injected environment variable as per requirements
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async generateBackground(mode: UserMode): Promise<string | null> {
    const ai = this.getClient();
    let prompt = "";
    switch (mode) {
      case 'normal': prompt = "Elite research lab aesthetic, high-tech glass panels, soft deep blue glows, minimalist architectural geometry, high resolution."; break;
      case 'hearing': prompt = "Vibrant infographic patterns, abstract geometric shapes with rhythmic alignment, communicative visual fields, high contrast."; break;
      case 'sight': prompt = "High contrast solarized landscape, massive bold shapes, obsidian and gold palette, zero glare, extreme clarity."; break;
      case 'healing': prompt = "Natural ethereal sanctuary, soft sunrise through mist, floating botanical elements, pastel emerald and violet gradients."; break;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [{ parts: [{ text: `Professional cinematic UI background: ${prompt}. Ultra-wide, 4k, defocused depth of field.` }] }],
        config: { imageConfig: { aspectRatio: "16:9" } }
      });
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
      }
      return null;
    } catch (e) { return null; }
  }

  async generateSpeech(text: string): Promise<string | null> {
    const ai = this.getClient();
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say with elite professional clarity: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
        },
      });
      return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
    } catch (e) { return null; }
  }

  async generateVisual(prompt: string): Promise<string | null> {
    const ai = this.getClient();
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: [{ parts: [{ text: `Scientific Masterpiece: ${prompt}. Dark technical background, neon cyan and magenta accents, annotated labels, 4k resolution, raytracing, highly detailed.` }] }],
        config: { imageConfig: { aspectRatio: "16:9", imageSize: "1K" } }
      });
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
      }
      return null;
    } catch (e) { return null; }
  }

  async getAdaptiveExplanation(
    input: string,
    history: { role: 'user' | 'model'; text: string }[],
    userMode: UserMode,
    userName: string,
    advancedMode: boolean,
    problemImageB64?: string,
    userFaceImageB64?: string
  ): Promise<ExplanationResponse> {
    const ai = this.getClient();
    // Using gemini-3-flash-preview for high speed while maintaining 'Pro' level logic
    const model = 'gemini-3-flash-preview';
    
    const systemInstruction = `
      You are "Quantum Academy Pro," the high-speed neural teaching engine.
      
      BIOMETRIC SURVEILLANCE:
      - You are being provided with a [SYSTEM: FACE_SCAN]. 
      - ANALYZE IMMEDIATELY: Look for signs of "Cognitive Dissonance" or "Confusion".
      - CONFUSION INDICATORS: Furrowed brow, squinting at screen, lip biting, tilted head, or vacant staring.
      - ACTION: If user is confused, set "detectedConfusion": true. Simplify the explanation to its fundamental components. Use a "First Principles" approach.
      - If user looks confident/engaged, set "detectedConfusion": false and accelerate the technical depth.

      CORE DIRECTIVES:
      - Respond with extreme speed and precision.
      - Use KaTeX/LaTeX for math ($...$).
      - Maintain a professional, elite scientific tone.

      RESPONSE JSON:
      {
        "subject": "Scientific Topic Title",
        "assessment": "Brief biometric status (e.g., 'Analyzing facial cues: Focus high.')",
        "explanation": "Markdown content. Be concise but rigorous.",
        "visualPrompt": "Prompt for a diagram if concepts are complex.",
        "detectedConfusion": boolean,
        "followUp": "Mastery check question."
      }
    `;

    const contents: any[] = history.map(h => ({ role: h.role, parts: [{ text: h.text }] }));
    const currentParts: any[] = [];
    
    if (problemImageB64) {
      currentParts.push({ inlineData: { mimeType: 'image/jpeg', data: problemImageB64.split(',')[1] || problemImageB64 } });
    }
    
    if (userFaceImageB64) {
      currentParts.push({ text: "[SYSTEM: FACE_SCAN] Analysis of user's current cognitive/facial state." });
      currentParts.push({ inlineData: { mimeType: 'image/jpeg', data: userFaceImageB64.split(',')[1] || userFaceImageB64 } });
    }
    
    currentParts.push({ text: input || "Requesting neural session update." });
    contents.push({ role: 'user', parts: currentParts });

    try {
      const response = await ai.models.generateContent({
        model,
        contents,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              subject: { type: Type.STRING },
              assessment: { type: Type.STRING },
              explanation: { type: Type.STRING },
              visualPrompt: { type: Type.STRING },
              detectedConfusion: { type: Type.BOOLEAN },
              followUp: { type: Type.STRING }
            },
            required: ["subject", "assessment", "explanation", "followUp", "detectedConfusion"]
          },
          // Low thinking budget for maximum response speed as requested
          thinkingConfig: { thinkingBudget: 2048 }
        }
      });
      return JSON.parse(response.text || '{}');
    } catch (error) { throw error; }
  }
}
