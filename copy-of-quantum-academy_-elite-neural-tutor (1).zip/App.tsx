
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Message, AppSettings, UserMode } from './types';
import { AdaptiveAcademyService } from './services/geminiService';

const STORAGE_KEYS = {
  HISTORY: 'quantum_academy_pro_history',
  SETTINGS: 'quantum_academy_pro_settings',
  BACKGROUND: 'quantum_academy_pro_bg'
};

/**
 * Decodes base64 string to Uint8Array.
 * Manual implementation as required by guidelines to avoid external dependencies.
 */
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Decodes raw PCM audio data into an AudioBuffer.
 * Implementation follows Gemini Live API guidelines for raw PCM streaming.
 */
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [visualizing, setVisualizing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showNameModal, setShowNameModal] = useState(false);
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [background, setBackground] = useState<string | null>(localStorage.getItem(STORAGE_KEYS.BACKGROUND));
  const [bgLoading, setBgLoading] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [hasApiKey, setHasApiKey] = useState<boolean>(true);

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : { 
        userName: '', userMode: 'normal' as UserMode, isCameraOn: true, advancedMode: true 
      };
    } catch (e) {
      return { userName: '', userMode: 'normal', isCameraOn: true, advancedMode: true };
    }
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const recognitionRef = useRef<any>(null);
  const audioContext = useRef<AudioContext | null>(null);
  const audioSource = useRef<AudioBufferSourceNode | null>(null);
  const academyService = useRef(new AdaptiveAcademyService());

  const visualsMemory = useMemo(() => messages.filter(m => m.generatedVisual).map(m => m.generatedVisual), [messages]);
  
  const lastAssessment = useMemo(() => {
    const lastModel = [...messages].reverse().find(m => m.role === 'model');
    if (!lastModel) return "Sync Ready";
    return lastModel.text.split('[[CONTENT]]')[0]?.replace('[[ASSESSMENT]]', '').replace('[[CONFUSED]]', '').trim() || "Calibrated";
  }, [messages]);

  const isConfused = useMemo(() => {
    const lastModel = [...messages].reverse().find(m => m.role === 'model');
    return lastModel?.text.includes('[[CONFUSED]]');
  }, [messages]);

  useEffect(() => {
    const init = async () => {
      // Check for mandatory API key selection as per Veo/Gemini-3 Pro guidelines
      const keySelected = await window.aistudio.hasSelectedApiKey();
      setHasApiKey(keySelected);

      const savedHistory = localStorage.getItem(STORAGE_KEYS.HISTORY);
      if (savedHistory) setMessages(JSON.parse(savedHistory));
      else if (!settings.userName || !keySelected) setShowNameModal(true);
      else {
        triggerGreeting();
        syncBackground();
      }
    };
    init();
  }, []);

  useEffect(() => {
    if (settings.isCameraOn) startCamera();
    else stopCamera();
  }, [settings.isCameraOn]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 320, height: 240 } });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      setSettings(prev => ({ ...prev, isCameraOn: false }));
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  const captureFrame = (): string | null => {
    if (!videoRef.current || !canvasRef.current || !settings.isCameraOn) return null;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    if (context) {
      canvas.width = 320;
      canvas.height = 240;
      context.drawImage(videoRef.current, 0, 0, 320, 240);
      return canvas.toDataURL('image/jpeg', 0.5);
    }
    return null;
  };

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(messages));
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
    if (window.renderMathInElement) window.renderMathInElement(document.body, {
      delimiters: [{left: '$$', right: '$$', display: true}, {left: '$', right: '$', display: false}],
      throwOnError: false
    });
  }, [messages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  const syncBackground = async (forceMode?: UserMode) => {
    setBgLoading(true);
    const bg = await academyService.current.generateBackground(forceMode || settings.userMode);
    if (bg) {
      setBackground(bg);
      localStorage.setItem(STORAGE_KEYS.BACKGROUND, bg);
    }
    setBgLoading(false);
  };

  const changeMode = (mode: UserMode) => {
    setSettings(p => ({ ...p, userMode: mode }));
    syncBackground(mode);
  };

  /**
   * Triggers the API key selection dialog.
   * Following the race condition mitigation guideline: assume success and proceed.
   */
  const handleOpenKeyPicker = async () => {
    await window.aistudio.openSelectKey();
    setHasApiKey(true);
    if (settings.userName) {
      triggerGreeting();
      syncBackground();
    }
  };

  const triggerGreeting = async (name?: string) => {
    setLoading(true);
    try {
      const uName = name || settings.userName;
      const res = await academyService.current.getAdaptiveExplanation(
        `Initialize high-speed neural link for ${uName}.`, [], settings.userMode, uName, settings.advancedMode
      );
      setMessages([{ 
        role: 'model', 
        text: `[[ASSESSMENT]]Neural Link Synchronized[[CONTENT]]### Welcome, ${uName}\n\n${res.explanation}\n\n${res.followUp}`,
        timestamp: Date.now() 
      }]);
    } catch (e: any) {
      // Implement robust handling for 404 error per guidelines
      if (e.message?.includes("Requested entity was not found")) {
        setHasApiKey(false);
        await window.aistudio.openSelectKey();
        setHasApiKey(true);
      }
      setMessages([{ role: 'model', text: "Neural feed established. Command center ready.", timestamp: Date.now() }]);
    }
    setLoading(false);
  };

  const toggleVoice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      if (!recognitionRef.current) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setInput(prev => prev + (prev ? ' ' : '') + transcript);
        };
        recognitionRef.current.onend = () => setIsListening(false);
      }
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  const handlePlaySpeech = async (text: string, id: number) => {
    if (playingId === id) { audioSource.current?.stop(); setPlayingId(null); return; }
    setPlayingId(id);
    const audioDataB64 = await academyService.current.generateSpeech(text.replace(/[*#$]/g, ''));
    if (!audioDataB64) { setPlayingId(null); return; }
    if (!audioContext.current) audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
    const buffer = await decodeAudioData(decodeBase64(audioDataB64), audioContext.current, 24000, 1);
    if (audioSource.current) audioSource.current.stop();
    const source = audioContext.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContext.current.destination);
    source.onended = () => setPlayingId(null);
    source.start();
    audioSource.current = source;
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage) return;
    const currentInput = input;
    const currentImg = selectedImage;
    
    let faceFrame = captureFrame();
    if (faceFrame) setIsScanning(true);

    const userMsg: Message = { role: 'user', text: currentInput, image: currentImg || undefined, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setSelectedImage(null);
    setLoading(true);

    try {
      const history = messages.slice(-4).map(m => ({ role: m.role, text: m.text }));
      const res = await academyService.current.getAdaptiveExplanation(
        currentInput, history, settings.userMode, settings.userName, settings.advancedMode, currentImg || undefined, faceFrame || undefined
      );
      
      let modelMsg: Message = { 
        role: 'model', 
        text: `[[ASSESSMENT]]${res.assessment}${res.detectedConfusion ? "[[CONFUSED]]" : ""}[[CONTENT]]### ${res.subject}\n\n${res.explanation}\n\n---\n**Mastery Check:** ${res.followUp}`, 
        timestamp: Date.now() 
      };

      if (res.visualPrompt) {
        setVisualizing(true);
        modelMsg.generatedVisual = (await academyService.current.generateVisual(res.visualPrompt)) || undefined;
        setVisualizing(false);
      }

      setMessages(prev => [...prev, modelMsg]);
      setIsScanning(false);
    } catch (e: any) {
      // Implement robust handling for 404 error per guidelines
      if (e.message?.includes("Requested entity was not found")) {
        setHasApiKey(false);
        await window.aistudio.openSelectKey();
        setHasApiKey(true);
      }
      setMessages(prev => [...prev, { role: 'model', text: "Signal lost. Re-establishing connection...", timestamp: Date.now() }]);
      setIsScanning(false);
    }
    setLoading(false);
  };

  const renderContent = (msg: Message) => {
    const parts = msg.text.split('[[CONTENT]]');
    const header = parts[0] || "";
    const isConfusedMsg = header.includes('[[CONFUSED]]');
    const assessmentText = header.replace('[[ASSESSMENT]]', '').replace('[[CONFUSED]]', '').trim();
    const body = parts[1] || msg.text;

    return (
      <div className="space-y-6">
        <div className="flex gap-2">
          {assessmentText && (
            <div className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded text-[10px] font-bold text-cyan-400 uppercase tracking-tighter">
              {assessmentText}
            </div>
          )}
          {isConfusedMsg && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
              className="px-3 py-1 bg-amber-500/20 border border-amber-500/50 rounded text-[10px] font-black text-amber-500 uppercase animate-pulse flex items-center gap-2"
            >
              <i className="fas fa-brain"></i> BIOMETRIC MISMATCH DETECTED
            </motion.div>
          )}
        </div>

        {msg.generatedVisual && (
          <div className="rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
            <img src={msg.generatedVisual} className="w-full object-cover aspect-video" alt="Scientific Visual" />
          </div>
        )}

        <div className="prose prose-invert max-w-none math-render text-slate-200 leading-relaxed font-light">
          {body.split('\n').map((l, i) => <p key={i} className="mb-4">{l}</p>)}
        </div>

        <button onClick={() => handlePlaySpeech(body, msg.timestamp)} className="flex items-center gap-2 text-[10px] font-black uppercase text-cyan-400/60 hover:text-cyan-400 transition-colors">
          <i className={`fas ${playingId === msg.timestamp ? 'fa-stop-circle' : 'fa-volume-up'}`}></i>
          {playingId === msg.timestamp ? 'Terminate Audio Feed' : 'Synthesize Audio Feed'}
        </button>
      </div>
    );
  };

  return (
    <div className="relative h-screen w-full flex bg-[#020617] text-slate-100 overflow-hidden font-sans">
      <AnimatePresence mode="wait">
        <motion.div 
          key={background} initial={{ opacity: 0 }} animate={{ opacity: 0.5 }} exit={{ opacity: 0 }}
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{ backgroundImage: background ? `url(${background})` : 'none' }}
        >
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-[2px]" />
        </motion.div>
      </AnimatePresence>

      <canvas ref={canvasRef} className="hidden" />

      {/* SIDEBAR */}
      <motion.aside 
        animate={{ width: sidebarOpen ? '320px' : '0px', opacity: sidebarOpen ? 1 : 0 }}
        className="relative z-20 h-full border-r border-white/5 bg-slate-950/40 backdrop-blur-3xl flex flex-col overflow-hidden"
      >
        <div className="p-8 space-y-10 flex-1 overflow-y-auto scrollbar-hide">
          <div className="space-y-1">
            <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-cyan-500/50 italic">Neural HUD</h3>
            <p className="text-2xl font-black tracking-tighter italic">QUANTUM ACADEMY</p>
          </div>

          <div className="space-y-6">
            <div className="bg-white/5 p-5 rounded-3xl border border-white/5 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold uppercase text-slate-400">Cognitive Alignment</span>
                <span className={`text-[10px] font-bold ${isConfused ? 'text-amber-400' : 'text-cyan-400'}`}>{isConfused ? 'Critical' : 'Sync: 98%'}</span>
              </div>
              <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                <motion.div animate={{ width: isConfused ? '20%' : '98%' }} className={`h-full transition-all duration-700 ${isConfused ? 'bg-amber-500 shadow-[0_0_15px_#f59e0b]' : 'bg-cyan-400 shadow-[0_0_15px_#22d3ee]'}`} />
              </div>
              <p className="text-[9px] text-slate-500 uppercase tracking-widest leading-relaxed">{lastAssessment}</p>
            </div>

            {settings.isCameraOn && (
              <div className="relative group rounded-3xl overflow-hidden aspect-video border border-cyan-500/30 shadow-2xl">
                <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 transition-all duration-500" />
                <div className="absolute inset-0 biometric-scan-line pointer-events-none opacity-60" />
                <div className="absolute top-3 left-3 flex gap-2">
                  <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
                  <span className="text-[8px] font-black text-cyan-400 uppercase">Live_Biometric_Sync</span>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest">Memory Cache</h4>
            <div className="grid grid-cols-2 gap-3">
              {visualsMemory.slice(-4).map((v, i) => (
                <div key={i} className="aspect-square rounded-2xl overflow-hidden border border-white/10 hover:border-cyan-500/50 transition-colors bg-white/5 cursor-pointer">
                  <img src={v} className="w-full h-full object-cover opacity-50 hover:opacity-100 transition-opacity" alt="Cached visual" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.aside>

      {/* MAIN */}
      <main className="flex-1 flex flex-col relative z-10">
        <header className="px-10 py-6 flex items-center justify-between border-b border-white/5 bg-slate-950/20 backdrop-blur-xl">
          <div className="flex items-center gap-6">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-slate-400 hover:text-white transition-colors">
              <i className={`fas ${sidebarOpen ? 'fa-indent' : 'fa-outdent'} text-lg`}></i>
            </button>
            <div className="flex items-center gap-3">
              <i className="fas fa-microchip text-cyan-400 text-xl animate-pulse"></i>
              <span className="text-sm font-black uppercase tracking-[0.3em] italic">System Core <span className="text-cyan-500/30 text-[9px] font-normal not-italic tracking-normal">Online</span></span>
            </div>
          </div>

          <div className="flex items-center bg-black/40 p-1.5 rounded-2xl border border-white/5 gap-1">
            {(['normal', 'hearing', 'sight', 'healing'] as UserMode[]).map(m => (
              <button 
                key={m} onClick={() => changeMode(m)} 
                className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                  settings.userMode === m ? 'bg-cyan-500 text-black shadow-[0_0_20px_rgba(34,211,238,0.4)]' : 'text-slate-500 hover:text-white'
                }`}
              >
                {m}
              </button>
            ))}
            <div className="w-[1px] h-6 bg-white/10 mx-2" />
            <button onClick={() => setSettings(p => ({ ...p, isCameraOn: !p.isCameraOn }))} className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${settings.isCameraOn ? 'bg-cyan-500/20 text-cyan-400' : 'bg-white/5 text-slate-600'}`}>
              <i className="fas fa-eye"></i>
            </button>
          </div>
        </header>

        <section className="flex-1 overflow-y-auto px-10 py-12 space-y-16 scroll-smooth scrollbar-hide">
          {messages.map((m) => (
            <motion.div key={m.timestamp} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-10 rounded-[3rem] border shadow-2xl transition-all duration-500 ${
                m.role === 'user' 
                ? 'bg-indigo-950/50 border-indigo-500/20 text-white rounded-tr-none' 
                : `rounded-tl-none ${isConfused && m.timestamp === messages[messages.length-1]?.timestamp ? 'bg-amber-950/20 border-amber-500/20' : 'bg-white/5 border-white/5 backdrop-blur-3xl'}`
              }`}>
                {m.image && <img src={m.image} className="max-w-md rounded-3xl mb-8 border border-white/10 shadow-2xl" alt="Material" />}
                {m.role === 'model' ? renderContent(m) : <p className="text-base font-light tracking-wide text-slate-100">{m.text}</p>}
              </div>
            </motion.div>
          ))}
          <AnimatePresence>
            {(loading || visualizing || isScanning) && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                <div className="flex items-center gap-5 bg-white/5 border border-white/5 px-8 py-4 rounded-3xl text-[10px] font-black uppercase text-cyan-400 tracking-[0.2em] italic shadow-2xl">
                  <i className="fas fa-wave-square fa-spin text-lg"></i>
                  {isScanning ? 'Synchronizing Biometrics...' : visualizing ? 'Rendering Visual Field...' : 'Synthesizing Neural Response...'}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={scrollRef} />
        </section>

        <footer className="p-10 border-t border-white/5 bg-slate-950/40 backdrop-blur-3xl">
          <div className="max-w-5xl mx-auto flex gap-6 items-end">
            <div className="flex-1 relative group">
              <textarea 
                value={input} onChange={e => setInput(e.target.value)} 
                onKeyDown={e => { if(e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); handleSend(); }}} 
                placeholder="Initiate high-speed neural query..." 
                className="w-full p-7 rounded-[2.5rem] bg-white/5 border-2 border-white/5 focus:border-cyan-500/40 text-slate-100 text-base outline-none transition-all resize-none h-20 max-h-56 shadow-inner" 
              />
            </div>
            
            <button onClick={toggleVoice} className={`w-20 h-20 rounded-[2rem] flex items-center justify-center text-2xl shadow-2xl transition-all ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
              <i className={`fas ${isListening ? 'fa-microphone-slash' : 'fa-microphone'}`}></i>
            </button>
            
            <button onClick={handleSend} className="w-20 h-20 rounded-[2rem] bg-cyan-500 text-black flex items-center justify-center text-2xl shadow-[0_0_40px_rgba(34,211,238,0.3)] hover:scale-105 active:scale-95 transition-transform">
              <i className="fas fa-paper-plane"></i>
            </button>
          </div>
        </footer>
      </main>

      {/* MODAL & API KEY HANDLER */}
      <AnimatePresence>
        {(showNameModal || !hasApiKey) && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex items-center justify-center bg-[#020617] p-8">
            <div className="max-w-lg w-full bg-slate-950/60 backdrop-blur-3xl p-14 rounded-[4rem] border border-cyan-500/20 text-center space-y-10 shadow-2xl">
              <div className="space-y-4">
                <i className="fas fa-atom text-7xl text-cyan-400 animate-spin-slow"></i>
                <h2 className="text-4xl font-black uppercase italic tracking-tighter">QUANTUM ACADEMY</h2>
                <p className="text-[11px] font-bold text-slate-500 uppercase tracking-[0.3em]">Pro_Neural_Interface_v2</p>
              </div>

              {!hasApiKey ? (
                <div className="space-y-6">
                  <p className="text-sm text-slate-400 leading-relaxed">
                    A paid API key is required for premium visual synthesis (Gemini 3 Pro). 
                    Please ensure your selected key is from a paid GCP project.
                  </p>
                  <a 
                    href="https://ai.google.dev/gemini-api/docs/billing" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="block text-[10px] font-black text-cyan-500 uppercase tracking-widest hover:underline"
                  >
                    View Billing Documentation
                  </a>
                  <button 
                    onClick={handleOpenKeyPicker}
                    className="w-full p-6 bg-cyan-500 text-black font-black uppercase tracking-widest rounded-3xl shadow-[0_0_30px_rgba(34,211,238,0.4)] hover:scale-[1.02] transition-transform"
                  >
                    Select API Key
                  </button>
                </div>
              ) : (
                <>
                  <input 
                    id="name-init"
                    type="text" 
                    placeholder="Designate Operator Identity..." 
                    className="w-full bg-slate-900/50 border-2 border-white/5 p-6 rounded-3xl outline-none focus:border-cyan-500 transition-all text-center text-xl text-white font-light tracking-wide" 
                    onKeyDown={e => { if(e.key === 'Enter') { const n = (e.target as any).value; if(n){ setSettings(p => ({...p, userName: n})); setShowNameModal(false); triggerGreeting(n); syncBackground(); }}}} 
                  />
                  <button 
                    className="w-full p-6 bg-cyan-500 text-black font-black uppercase tracking-widest rounded-3xl shadow-[0_0_30px_rgba(34,211,238,0.4)] hover:scale-[1.02] transition-transform" 
                    onClick={() => { const n = (document.getElementById('name-init') as HTMLInputElement).value; if(n){ setSettings(p => ({...p, userName: n})); setShowNameModal(false); triggerGreeting(n); syncBackground(); }}}
                  >
                    Establish Neural Sync
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .animate-spin-slow { animation: spin 15s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .biometric-scan-line {
          height: 3px;
          background: #22d3ee;
          box-shadow: 0 0 20px #22d3ee;
          position: absolute;
          width: 100%;
          animation: scan 4s linear infinite;
        }
        @keyframes scan {
          0% { top: 0; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default App;
